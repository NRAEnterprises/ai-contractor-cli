"""Supported model providers and interface combinations."""
from dataclasses import dataclass

@dataclass(frozen=True)
class Provider:
    name: str
    interfaces: tuple[str, ...]

PROVIDERS = {
    "anthropic": Provider("Anthropic", ("cli", "web", "gui")),
    "openai": Provider("OpenAI", ("cli", "web", "api")),
    "google": Provider("Google", ("web", "gui")),
    "lmstudio": Provider("LM Studio", ("gui",)),
    "ollama": Provider("Ollama", ("cli", "gui")),
    "generic": Provider("Generic", ("cli", "web", "gui", "api")),
    "custom": Provider("Custom", ("cli", "web", "gui", "api")),
}
INTERFACES = ("cli", "web", "gui", "api")


def provider_names() -> list[str]:
    return sorted(PROVIDERS)


def validate_pair(provider: str, interface: str) -> None:
    from .errors import ValidationError
    provider, interface = provider.lower(), interface.lower()
    if provider not in PROVIDERS:
        raise ValidationError(f"Unknown provider '{provider}'. Choose from: {', '.join(provider_names())}")
    if interface not in INTERFACES:
        raise ValidationError(f"Unknown interface '{interface}'. Choose from: {', '.join(INTERFACES)}")
    if interface not in PROVIDERS[provider].interfaces:
        raise ValidationError(f"Provider '{provider}' does not have a configured {interface} profile")
