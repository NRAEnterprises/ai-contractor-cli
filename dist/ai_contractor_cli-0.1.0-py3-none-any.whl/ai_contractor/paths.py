"""Portable storage paths and safe session lookup."""
import os
from pathlib import Path
from .errors import SessionNotFoundError

APP_DIR = "ai-contractor-cli"


def data_home() -> Path:
    override = os.environ.get("AI_CONTRACTOR_HOME")
    if override:
        return Path(override).expanduser().resolve()
    xdg = os.environ.get("XDG_DATA_HOME")
    return Path(xdg).expanduser() / APP_DIR if xdg else Path.home() / ".ai-contractor-cli"


def config_path() -> Path:
    override = os.environ.get("AI_CONTRACTOR_CONFIG")
    return Path(override).expanduser() if override else data_home() / "config.toml"


def sessions_dir(root: Path | None = None) -> Path:
    return (root or data_home()) / "sessions"


def amendments_dir(root: Path | None = None) -> Path:
    return (root or data_home()) / "amendments"


def session_dir(session_id: str, root: Path | None = None) -> Path:
    # Session IDs are generated UUIDs but validate caller-supplied IDs against traversal.
    if not session_id or Path(session_id).name != session_id or session_id in {".", ".."}:
        raise SessionNotFoundError("Invalid session ID")
    base = sessions_dir(root).resolve()
    matches = list(base.glob(f"*/{session_id}")) if base.exists() else []
    for candidate in matches:
        if candidate.resolve().parent.parent == base:
            return candidate
    raise SessionNotFoundError(f"Session not found: {session_id}")
