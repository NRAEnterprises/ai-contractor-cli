"""Optional self-audit prompts included in generated contracts."""
import json
from importlib.resources import files


def prompts() -> list[str]:
    path = files("ai_contractor").joinpath("data/conduct_prompts.json")
    return json.loads(path.read_text(encoding="utf-8"))


def checklist() -> str:
    return "\n".join(f"- [ ] {item}" for item in prompts())
