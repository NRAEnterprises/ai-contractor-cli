"""Input and session validation."""
import json
from pathlib import Path
from typing import Any
from .errors import ValidationError


def require_text(value: str, label: str) -> str:
    value = (value or "").strip()
    if not value:
        raise ValidationError(f"{label} must not be empty")
    return value


def load_json(path: Path) -> Any:
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        raise ValidationError(f"Cannot read valid JSON from {path}: {exc}") from exc


def validate_session(record: Any) -> None:
    required = {"session_id", "project_id", "status", "provider", "interface", "created_at"}
    if not isinstance(record, dict) or not required.issubset(record):
        missing = sorted(required - set(record if isinstance(record, dict) else {}))
        raise ValidationError("Invalid session record; missing: " + ", ".join(missing))
    if record["status"] not in {"open", "complete", "halted"}:
        raise ValidationError("Session status must be open, complete, or halted")
