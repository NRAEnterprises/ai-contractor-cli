"""Command-line entry point."""
import argparse
import sys
from ._version import __version__
from .errors import ContractorError
from .commands import init_cmd, close_cmd, amend_cmd, show_cmd, verify_cmd, list_cmd
from .commands.help_cmd import run as help_run
from .commands.version_cmd import run as version_run


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="ai-contractor", description="Create and manage AI completion contracts")
    parser.add_argument("--version", action="version", version=f"ai-contractor {__version__}")
    subs = parser.add_subparsers(dest="command")
    init_cmd.configure(subs)
    close_cmd.configure(subs)
    amend_cmd.configure(subs)
    show_cmd.configure(subs)
    verify_cmd.configure(subs)
    list_cmd.configure(subs)
    help_parser = subs.add_parser("help", help="Show command help")
    help_parser.set_defaults(handler=help_run)
    version_parser = subs.add_parser("version", help="Show version")
    version_parser.set_defaults(handler=version_run)
    return parser


def main(argv: list[str] | None = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)
    if not args.command:
        parser.print_help()
        return 0
    try:
        return int(args.handler(args) or 0)
    except (ContractorError, OSError, ValueError) as exc:
        print(f"error: {exc}", file=sys.stderr)
        return 2

if __name__ == "__main__":
    raise SystemExit(main())
