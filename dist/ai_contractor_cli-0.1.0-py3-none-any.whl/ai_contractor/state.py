"""Session persistence; records are written atomically."""
import json
import os
import tempfile
from pathlib import Path
from typing import Any
from .errors import SessionNotFoundError
from .paths import data_home, session_dir, sessions_dir
from .validate import validate_session


def atomic_json(path: Path, data: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, temp_name = tempfile.mkstemp(prefix=".tmp-", dir=str(path.parent))
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as stream:
            json.dump(data, stream, indent=2, ensure_ascii=False)
            stream.write("\n")
        os.replace(temp_name, path)
    except Exception:
        try:
            os.unlink(temp_name)
        except OSError:
            pass
        raise


def save_session(record: dict, root: Path | None = None) -> Path:
    validate_session(record)
    base = root or data_home()
    folder = base / "sessions" / record["project_id"] / record["session_id"]
    folder.mkdir(parents=True, exist_ok=True)
    atomic_json(folder / "04_SESSION.json", record)
    return folder


def load_session(session_id: str, root: Path | None = None) -> dict:
    folder = session_dir(session_id, root)
    path = folder / "04_SESSION.json"
    if not path.is_file():
        raise SessionNotFoundError(f"Session record missing: {session_id}")
    record = json.loads(path.read_text(encoding="utf-8"))
    validate_session(record)
    return record


def list_sessions(root: Path | None = None) -> list[dict]:
    result = []
    base = sessions_dir(root)
    for path in sorted(base.glob("*/*/04_SESSION.json")) if base.exists() else []:
        try:
            record = json.loads(path.read_text(encoding="utf-8"))
            validate_session(record)
            result.append(record)
        except (ValueError, OSError):
            continue
    return result
