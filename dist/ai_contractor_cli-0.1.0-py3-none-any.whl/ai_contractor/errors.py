"""Domain errors used by the CLI."""

class ContractorError(Exception):
    """Expected user-facing error."""

class ValidationError(ContractorError):
    """Input or stored data is invalid."""

class SessionNotFoundError(ContractorError):
    """Requested session does not exist."""
